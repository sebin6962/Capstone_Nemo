using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DagwaItem : MonoBehaviour
{
    public string dagwaName = "Baekseolgi";
    public Sprite dagwaSprite;
}
