using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

//public class SelectedSlot : MonoBehaviour
//{
//    [SerializeField] private Image icon;
//    /*[SerializeField] private TMP_Text nameText;*/
//    public string itemName;
//    public Sprite itemSprite;
//    public int itemCount;
//    public void Set(MillItemData item)
//    {
//        icon.sprite = item.icon;
//        /*nameText.text = item.itemName;*/
//    }

//    // ������ ���� �޼��� ����
//    public void SetItem(string name, Sprite sprite, int count)
//    {
//        itemName = name;
//        itemSprite = sprite;
//        itemCount = count;
//        // UI�� ����ȭ
//    }

//    public void Clear()
//    {
//        icon.sprite = null;
//        /*nameText.text = "";*/
//    }
//}

public class SelectedSlot : MonoBehaviour
{
    [SerializeField] private Image icon;
    public string itemName;
    public Sprite itemSprite;
    public int itemCount;

    public void SetItem(string name, Sprite sprite, int count)
    {
        itemName = name;
        itemSprite = sprite;
        itemCount = count;
        icon.sprite = sprite;
        icon.enabled = true;
    }

    public void Clear()
    {
        icon.sprite = null;
        icon.enabled = false;
        itemName = "";
        itemSprite = null;
        itemCount = 0;
    }
}
