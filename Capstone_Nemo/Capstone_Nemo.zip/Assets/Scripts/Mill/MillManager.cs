using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//public class MillManager : MonoBehaviour
//{
//    public GameObject MillPanel;
//    public Transform inventoryPanelParent;
//    public GameObject SlotPrefab;
//    public SelectedSlot selectedSlot;
//    public Sprite[] testIcons;
//    public Button confirmButton;

//    private MillItemData selectedItem = null;
//    private List<MillItemData> Inventory;

//    void Start()
//    {
//        Inventory = new List<MillItemData>
//        {
//            new MillItemData(/*"��",*/ testIcons[0], 3),
//            new MillItemData(/*"����",*/ testIcons[1], 5),
//            new MillItemData(/*"��ȣ��",*/ testIcons[2], 2)
//        };

//        confirmButton.onClick.AddListener(Confirm);
//        confirmButton.interactable = false;
//        OpenMill();
//    }
//    public void OpenMill()
//    {
//        gameObject.SetActive(true);

//        foreach (Transform child in inventoryPanelParent)
//            Destroy(child.gameObject);

//        foreach (var item in Inventory)
//        {
//            var obj = Instantiate(SlotPrefab, inventoryPanelParent);
//            obj.GetComponent<MillInventory>().Setup(item, this);
//        }

//        selectedItem = null;
//        selectedSlot.Clear();

//    }


//    public void SelectItem(MillItemData item)
//    {
//        if (ReferenceEquals(selectedItem, item))
//        {
//            item.itemQuantity += 1;
//            selectedItem = null;
//            selectedSlot.Clear();
//            UpdateInventoryUI();
//            confirmButton.interactable = false;  
//            return;
//        }

//        if (item.itemQuantity <= 0)
//            return;

//        if (selectedItem != null)
//            selectedItem.itemQuantity += 1;

//        item.itemQuantity -= 1;
//        selectedItem = item;
//        selectedSlot.Set(item);
//        UpdateInventoryUI();
//        confirmButton.interactable = true;  
//    }

//    private void UpdateInventoryUI()
//    {
//        foreach (Transform child in inventoryPanelParent)
//        {
//            var slot = child.GetComponent<MillInventory>();
//            slot?.UpdateQuantityText();
//        }
//    }



//    public void Confirm()
//    {
//        /*Debug.Log($"[Confirm ȣ��] MillManager �ν��Ͻ�: {this.GetInstanceID()}");

//        Debug.Log("Confirm ���� - ���õ� ������: " + (selectedItem != null ? selectedItem.icon.name : "null"));*/

//        /*if (selectedItem == null)
//        {
//            Debug.Log("���õ� �������� ���� Confirm ��ҵ�");
//            return;
//        }*/

//        Debug.Log($"{selectedItem.icon.name} �������� ����� ������");

//        selectedItem = null;
//        selectedSlot.Clear();
//        UpdateInventoryUI();
//        confirmButton.interactable = false;

//    }

//    public void CloseMill()
//    {
//        if (selectedItem != null)
//        {
//            selectedItem.itemQuantity += 1;
//            selectedSlot.Clear();
//            selectedItem = null;
//            UpdateInventoryUI();
//        }
//        MillPanel.SetActive(false);
//    }
//}

public class MillManager : MonoBehaviour
{
    public GameObject MillPanel;
    public List<StorageInventorySlot> slots;     // inspector�� �̸� ���� ����
    public Button confirmButton;

    public SelectedSlot selectedSlot;
    public StorageInventory storageInventory; // �κ��丮(â��) �ý���

    // ����� �� ���� ������ ����
    private static readonly Dictionary<string, string> flourMapping = new()
    {
        { "Rice", "Mepssalgaru" },
        { "Mugwort", "Mugwortgaru" },
        { "Chapssal", "Chapssalgaru" },
        { "Danhobak", "Danhobakgaru" },
        { "Baeknyeoncho", "Baeknyeonchogaru" }
    };

    void Start()
    {
        confirmButton.onClick.AddListener(Confirm);
        confirmButton.interactable = false;
        // selectedSlot Ŭ�� �̺�Ʈ ���� (�� ����)
        selectedSlot.GetComponent<Button>().onClick.AddListener(OnSelectedSlotClicked);
        OpenMill();
    }

    public void OpenMill()
    {
        MillPanel.SetActive(true);
        selectedSlot.Clear();
        confirmButton.interactable = false;
        UpdateSlots();
    }

    // Storage�� ���� �����ϴ� �����۸� ���Կ� ���
    public void UpdateSlots()
    {
        foreach (var slot in slots) slot.ClearSlot();

        int i = 0;
        foreach (var pair in storageInventory.GetAllItems())
        {
            if (i >= slots.Count) break;
            Sprite sprite = Resources.Load<Sprite>("Sprites/Ingredients/" + pair.Key);
            if (sprite == null) continue;
            slots[i].SetItem(pair.Key, sprite, pair.Value);

            int capturedIdx = i;
            Button btn = slots[i].GetComponent<Button>();
            if (btn != null)
            {
                btn.onClick.RemoveAllListeners();
                btn.onClick.AddListener(() => OnSlotClicked(slots[capturedIdx].itemName, slots[capturedIdx].itemSprite));
            }
            i++;
        }
    }

    // ���� Ŭ�� ��, ����� 1�� storage���� ����, selectedSlot�� ����
    void OnSlotClicked(string itemName, Sprite sprite)
    {
        if (storageInventory.GetItemCount(itemName) > 0 && string.IsNullOrEmpty(selectedSlot.itemName))
        {
            storageInventory.AddItem(itemName, -1);
            selectedSlot.SetItem(itemName, sprite, 1);
            confirmButton.interactable = true;
            UpdateSlots();
        }
    }

    // Confirm(����� �����) ��ư: selectedSlot�� �������� ����� ��ȯ
    public void Confirm()
    {
        if (!string.IsNullOrEmpty(selectedSlot.itemName) && flourMapping.ContainsKey(selectedSlot.itemName))
        {
            string flourName = flourMapping[selectedSlot.itemName];
            Sprite flourSprite = Resources.Load<Sprite>("Sprites/Ingredients/" + flourName);
            selectedSlot.SetItem(flourName, flourSprite, 1);
            confirmButton.interactable = false;
        }
    }

    // selectedSlot Ŭ�� ��: ������ storage�� �̵�(�߰�) �� selectedSlot ���
    public void OnSelectedSlotClicked()
    {
        // ���� �����۸� storage�� �̵�
        if (!string.IsNullOrEmpty(selectedSlot.itemName) && IsFlour(selectedSlot.itemName))
        {
            storageInventory.AddItem(selectedSlot.itemName, 1);
            selectedSlot.Clear();
            UpdateSlots();
        }
    }

    // ���� ������ �Ǻ�
    private bool IsFlour(string itemName)
    {
        // flourMapping�� value �� �ϳ��� ������
        return flourMapping.ContainsValue(itemName);
    }

    // �г� �ݱ�(���� �̿ϼ� ��ȯ�� �ִٸ� ���󺹱�)
    public void CloseMill()
    {
        if (!string.IsNullOrEmpty(selectedSlot.itemName) && !IsFlour(selectedSlot.itemName))
        {
            // ����Ḹ ��ȯ
            storageInventory.AddItem(selectedSlot.itemName, 1);
            selectedSlot.Clear();
            UpdateSlots();
        }
        MillPanel.SetActive(false);
    }
}
