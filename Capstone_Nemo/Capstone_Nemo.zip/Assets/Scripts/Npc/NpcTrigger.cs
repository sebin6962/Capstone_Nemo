using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NpcTrigger : MonoBehaviour
{
    public static MillNpc nearestMillNpc = null;
    public static MillShopNpc nearestMillShopNpc = null;

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            if (GetComponent<MillNpc>() != null)
                nearestMillNpc = GetComponent<MillNpc>();
            if (GetComponent<MillShopNpc>() != null)
                nearestMillShopNpc = GetComponent<MillShopNpc>();
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            if (GetComponent<MillNpc>() != null)
                nearestMillNpc = null;
            if (GetComponent<MillShopNpc>() != null)
                nearestMillShopNpc = null;
        }
    }
}
