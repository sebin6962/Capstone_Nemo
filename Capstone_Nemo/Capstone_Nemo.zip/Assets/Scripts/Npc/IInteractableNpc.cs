﻿internal interface IInteractableNpc
{
}