using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MillShopNpc : MonoBehaviour
{
    public GameObject ShopPanel;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.E)
            && NpcTrigger.nearestMillShopNpc == this
            && !IsMillOpen()
            && !IsMillOpenOther()) // Mill�� ���������� Shop�� �� ������
        {
            Debug.Log("EŰ ���� - ��Ѱ� �� ��� �õ�");
            OpenShop();
        }
    }

    private void OpenShop()
    {
        ShopPanel.SetActive(true);
    }

    public bool IsMillOpen()
    {
        return ShopPanel.activeSelf;
    }

    private bool IsMillOpenOther()
    {
        var millNpc = FindObjectOfType<MillNpc>();
        return millNpc != null && millNpc.IsMillOpen();
    }
}
